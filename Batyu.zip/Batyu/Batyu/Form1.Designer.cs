﻿namespace Batyu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Batyu = new System.Windows.Forms.Label();
            this.Belépés = new System.Windows.Forms.Button();
            this.Regisztráció = new System.Windows.Forms.Button();
            this.Belépés_c = new System.Windows.Forms.Label();
            this.Felhasználónév_b = new System.Windows.Forms.Label();
            this.f_b_sz = new System.Windows.Forms.TextBox();
            this.j_b_sz = new System.Windows.Forms.TextBox();
            this.Jelszó_b = new System.Windows.Forms.Label();
            this.Belépés_g = new System.Windows.Forms.Button();
            this.Mégse_b = new System.Windows.Forms.Button();
            this.Mutasd_b = new System.Windows.Forms.CheckBox();
            this.Regisztráció_c = new System.Windows.Forms.Label();
            this.f_r_sz = new System.Windows.Forms.TextBox();
            this.Felhasználónév_r = new System.Windows.Forms.Label();
            this.Jelszó_r = new System.Windows.Forms.Label();
            this.j_r_sz = new System.Windows.Forms.TextBox();
            this.Mutasd_r = new System.Windows.Forms.CheckBox();
            this.Küldés = new System.Windows.Forms.Button();
            this.Mégse_r = new System.Windows.Forms.Button();
            this.Mutasd_r_m = new System.Windows.Forms.CheckBox();
            this.Jelszó_megerősítés = new System.Windows.Forms.Label();
            this.j_m_sz = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.Label();
            this.e_sz = new System.Windows.Forms.TextBox();
            this.Vezetéknév = new System.Windows.Forms.Label();
            this.V_sz = new System.Windows.Forms.TextBox();
            this.Keresztnév = new System.Windows.Forms.Label();
            this.K_sz = new System.Windows.Forms.TextBox();
            this.adatkezelés = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // Batyu
            // 
            this.Batyu.AutoSize = true;
            this.Batyu.Font = new System.Drawing.Font("Arial", 50.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Batyu.Location = new System.Drawing.Point(2, 9);
            this.Batyu.Name = "Batyu";
            this.Batyu.Size = new System.Drawing.Size(203, 75);
            this.Batyu.TabIndex = 0;
            this.Batyu.Text = "Batyu";
            // 
            // Belépés
            // 
            this.Belépés.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Belépés.BackColor = System.Drawing.Color.Blue;
            this.Belépés.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Belépés.Font = new System.Drawing.Font("Times New Roman", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Belépés.ForeColor = System.Drawing.Color.White;
            this.Belépés.Location = new System.Drawing.Point(430, 36);
            this.Belépés.Name = "Belépés";
            this.Belépés.Size = new System.Drawing.Size(136, 45);
            this.Belépés.TabIndex = 1;
            this.Belépés.Text = "Belépés";
            this.Belépés.UseVisualStyleBackColor = false;
            this.Belépés.Click += new System.EventHandler(this.Belépés_Click);
            // 
            // Regisztráció
            // 
            this.Regisztráció.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Regisztráció.BackColor = System.Drawing.Color.Blue;
            this.Regisztráció.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Regisztráció.Font = new System.Drawing.Font("Times New Roman", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Regisztráció.ForeColor = System.Drawing.Color.White;
            this.Regisztráció.Location = new System.Drawing.Point(582, 36);
            this.Regisztráció.Name = "Regisztráció";
            this.Regisztráció.Size = new System.Drawing.Size(191, 45);
            this.Regisztráció.TabIndex = 2;
            this.Regisztráció.Text = "Regisztráció";
            this.Regisztráció.UseVisualStyleBackColor = false;
            this.Regisztráció.Click += new System.EventHandler(this.Regisztráció_Click);
            // 
            // Belépés_c
            // 
            this.Belépés_c.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Belépés_c.AutoSize = true;
            this.Belépés_c.Font = new System.Drawing.Font("Arial", 50.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Belépés_c.Location = new System.Drawing.Point(241, 9);
            this.Belépés_c.Name = "Belépés_c";
            this.Belépés_c.Size = new System.Drawing.Size(274, 75);
            this.Belépés_c.TabIndex = 3;
            this.Belépés_c.Text = "Belépés";
            this.Belépés_c.Visible = false;
            // 
            // Felhasználónév_b
            // 
            this.Felhasználónév_b.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Felhasználónév_b.AutoSize = true;
            this.Felhasználónév_b.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Felhasználónév_b.Location = new System.Drawing.Point(127, 169);
            this.Felhasználónév_b.Name = "Felhasználónév_b";
            this.Felhasználónév_b.Size = new System.Drawing.Size(183, 31);
            this.Felhasználónév_b.TabIndex = 4;
            this.Felhasználónév_b.Text = "Felhasználónév";
            this.Felhasználónév_b.Visible = false;
            // 
            // f_b_sz
            // 
            this.f_b_sz.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.f_b_sz.Location = new System.Drawing.Point(334, 179);
            this.f_b_sz.Name = "f_b_sz";
            this.f_b_sz.Size = new System.Drawing.Size(172, 20);
            this.f_b_sz.TabIndex = 5;
            this.f_b_sz.Visible = false;
            // 
            // j_b_sz
            // 
            this.j_b_sz.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.j_b_sz.Location = new System.Drawing.Point(334, 217);
            this.j_b_sz.Name = "j_b_sz";
            this.j_b_sz.Size = new System.Drawing.Size(172, 20);
            this.j_b_sz.TabIndex = 7;
            this.j_b_sz.UseSystemPasswordChar = true;
            this.j_b_sz.Visible = false;
            // 
            // Jelszó_b
            // 
            this.Jelszó_b.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Jelszó_b.AutoSize = true;
            this.Jelszó_b.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Jelszó_b.Location = new System.Drawing.Point(127, 207);
            this.Jelszó_b.Name = "Jelszó_b";
            this.Jelszó_b.Size = new System.Drawing.Size(80, 31);
            this.Jelszó_b.TabIndex = 6;
            this.Jelszó_b.Text = "Jelszó";
            this.Jelszó_b.Visible = false;
            // 
            // Belépés_g
            // 
            this.Belépés_g.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Belépés_g.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Belépés_g.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Belépés_g.Location = new System.Drawing.Point(217, 345);
            this.Belépés_g.Name = "Belépés_g";
            this.Belépés_g.Size = new System.Drawing.Size(111, 42);
            this.Belépés_g.TabIndex = 8;
            this.Belépés_g.Text = "Belépés";
            this.Belépés_g.UseVisualStyleBackColor = true;
            this.Belépés_g.Visible = false;
            // 
            // Mégse_b
            // 
            this.Mégse_b.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Mégse_b.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Mégse_b.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Mégse_b.Location = new System.Drawing.Point(435, 345);
            this.Mégse_b.Name = "Mégse_b";
            this.Mégse_b.Size = new System.Drawing.Size(111, 42);
            this.Mégse_b.TabIndex = 9;
            this.Mégse_b.Text = "Mégse";
            this.Mégse_b.UseVisualStyleBackColor = true;
            this.Mégse_b.Visible = false;
            this.Mégse_b.Click += new System.EventHandler(this.Mégse_b_Click);
            // 
            // Mutasd_b
            // 
            this.Mutasd_b.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Mutasd_b.AutoSize = true;
            this.Mutasd_b.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Mutasd_b.Location = new System.Drawing.Point(334, 256);
            this.Mutasd_b.Name = "Mutasd_b";
            this.Mutasd_b.Size = new System.Drawing.Size(68, 19);
            this.Mutasd_b.TabIndex = 10;
            this.Mutasd_b.Text = "Mutasd";
            this.Mutasd_b.UseVisualStyleBackColor = true;
            this.Mutasd_b.Visible = false;
            this.Mutasd_b.CheckedChanged += new System.EventHandler(this.Mutasd_b_CheckedChanged);
            // 
            // Regisztráció_c
            // 
            this.Regisztráció_c.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Regisztráció_c.AutoSize = true;
            this.Regisztráció_c.Font = new System.Drawing.Font("Arial", 50.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Regisztráció_c.Location = new System.Drawing.Point(211, 9);
            this.Regisztráció_c.Name = "Regisztráció_c";
            this.Regisztráció_c.Size = new System.Drawing.Size(400, 75);
            this.Regisztráció_c.TabIndex = 11;
            this.Regisztráció_c.Text = "Regisztráció";
            this.Regisztráció_c.Visible = false;
            // 
            // f_r_sz
            // 
            this.f_r_sz.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.f_r_sz.Location = new System.Drawing.Point(374, 121);
            this.f_r_sz.Name = "f_r_sz";
            this.f_r_sz.Size = new System.Drawing.Size(172, 20);
            this.f_r_sz.TabIndex = 12;
            this.f_r_sz.Visible = false;
            // 
            // Felhasználónév_r
            // 
            this.Felhasználónév_r.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Felhasználónév_r.AutoSize = true;
            this.Felhasználónév_r.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Felhasználónév_r.Location = new System.Drawing.Point(176, 111);
            this.Felhasználónév_r.Name = "Felhasználónév_r";
            this.Felhasználónév_r.Size = new System.Drawing.Size(183, 31);
            this.Felhasználónév_r.TabIndex = 13;
            this.Felhasználónév_r.Text = "Felhasználónév";
            this.Felhasználónév_r.Visible = false;
            // 
            // Jelszó_r
            // 
            this.Jelszó_r.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Jelszó_r.AutoSize = true;
            this.Jelszó_r.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Jelszó_r.Location = new System.Drawing.Point(176, 144);
            this.Jelszó_r.Name = "Jelszó_r";
            this.Jelszó_r.Size = new System.Drawing.Size(80, 31);
            this.Jelszó_r.TabIndex = 15;
            this.Jelszó_r.Text = "Jelszó";
            this.Jelszó_r.Visible = false;
            // 
            // j_r_sz
            // 
            this.j_r_sz.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.j_r_sz.Location = new System.Drawing.Point(374, 154);
            this.j_r_sz.Name = "j_r_sz";
            this.j_r_sz.Size = new System.Drawing.Size(172, 20);
            this.j_r_sz.TabIndex = 14;
            this.j_r_sz.UseSystemPasswordChar = true;
            this.j_r_sz.Visible = false;
            // 
            // Mutasd_r
            // 
            this.Mutasd_r.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Mutasd_r.AutoSize = true;
            this.Mutasd_r.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Mutasd_r.Location = new System.Drawing.Point(374, 180);
            this.Mutasd_r.Name = "Mutasd_r";
            this.Mutasd_r.Size = new System.Drawing.Size(68, 19);
            this.Mutasd_r.TabIndex = 16;
            this.Mutasd_r.Text = "Mutasd";
            this.Mutasd_r.UseVisualStyleBackColor = true;
            this.Mutasd_r.Visible = false;
            this.Mutasd_r.CheckedChanged += new System.EventHandler(this.Mutasd_r_CheckedChanged);
            // 
            // Küldés
            // 
            this.Küldés.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Küldés.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Küldés.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Küldés.Location = new System.Drawing.Point(248, 423);
            this.Küldés.Name = "Küldés";
            this.Küldés.Size = new System.Drawing.Size(111, 42);
            this.Küldés.TabIndex = 17;
            this.Küldés.Text = "Küldés";
            this.Küldés.UseVisualStyleBackColor = true;
            this.Küldés.Visible = false;
            // 
            // Mégse_r
            // 
            this.Mégse_r.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Mégse_r.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Mégse_r.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Mégse_r.Location = new System.Drawing.Point(464, 423);
            this.Mégse_r.Name = "Mégse_r";
            this.Mégse_r.Size = new System.Drawing.Size(111, 42);
            this.Mégse_r.TabIndex = 18;
            this.Mégse_r.Text = "Mégse";
            this.Mégse_r.UseVisualStyleBackColor = true;
            this.Mégse_r.Visible = false;
            this.Mégse_r.Click += new System.EventHandler(this.Mégse_r_Click);
            // 
            // Mutasd_r_m
            // 
            this.Mutasd_r_m.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Mutasd_r_m.AutoSize = true;
            this.Mutasd_r_m.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Mutasd_r_m.Location = new System.Drawing.Point(374, 231);
            this.Mutasd_r_m.Name = "Mutasd_r_m";
            this.Mutasd_r_m.Size = new System.Drawing.Size(68, 19);
            this.Mutasd_r_m.TabIndex = 21;
            this.Mutasd_r_m.Text = "Mutasd";
            this.Mutasd_r_m.UseVisualStyleBackColor = true;
            this.Mutasd_r_m.Visible = false;
            this.Mutasd_r_m.CheckedChanged += new System.EventHandler(this.Mutasd_r_m_CheckedChanged);
            // 
            // Jelszó_megerősítés
            // 
            this.Jelszó_megerősítés.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Jelszó_megerősítés.AutoSize = true;
            this.Jelszó_megerősítés.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Jelszó_megerősítés.Location = new System.Drawing.Point(176, 195);
            this.Jelszó_megerősítés.Name = "Jelszó_megerősítés";
            this.Jelszó_megerősítés.Size = new System.Drawing.Size(152, 62);
            this.Jelszó_megerősítés.TabIndex = 20;
            this.Jelszó_megerősítés.Text = "Jelszó \r\nmegerősítése";
            this.Jelszó_megerősítés.Visible = false;
            // 
            // j_m_sz
            // 
            this.j_m_sz.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.j_m_sz.Location = new System.Drawing.Point(374, 205);
            this.j_m_sz.Name = "j_m_sz";
            this.j_m_sz.Size = new System.Drawing.Size(172, 20);
            this.j_m_sz.TabIndex = 19;
            this.j_m_sz.UseSystemPasswordChar = true;
            this.j_m_sz.Visible = false;
            // 
            // Email
            // 
            this.Email.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Email.AutoSize = true;
            this.Email.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Email.Location = new System.Drawing.Point(176, 264);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(133, 31);
            this.Email.TabIndex = 23;
            this.Email.Text = "E-mail cím";
            this.Email.Visible = false;
            // 
            // e_sz
            // 
            this.e_sz.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.e_sz.Location = new System.Drawing.Point(374, 268);
            this.e_sz.Name = "e_sz";
            this.e_sz.Size = new System.Drawing.Size(172, 20);
            this.e_sz.TabIndex = 22;
            this.e_sz.Visible = false;
            // 
            // Vezetéknév
            // 
            this.Vezetéknév.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Vezetéknév.AutoSize = true;
            this.Vezetéknév.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Vezetéknév.Location = new System.Drawing.Point(176, 306);
            this.Vezetéknév.Name = "Vezetéknév";
            this.Vezetéknév.Size = new System.Drawing.Size(137, 31);
            this.Vezetéknév.TabIndex = 25;
            this.Vezetéknév.Text = "Vezetéknév";
            this.Vezetéknév.Visible = false;
            // 
            // V_sz
            // 
            this.V_sz.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.V_sz.Location = new System.Drawing.Point(374, 306);
            this.V_sz.Name = "V_sz";
            this.V_sz.Size = new System.Drawing.Size(172, 20);
            this.V_sz.TabIndex = 24;
            this.V_sz.Visible = false;
            // 
            // Keresztnév
            // 
            this.Keresztnév.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Keresztnév.AutoSize = true;
            this.Keresztnév.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Keresztnév.Location = new System.Drawing.Point(176, 346);
            this.Keresztnév.Name = "Keresztnév";
            this.Keresztnév.Size = new System.Drawing.Size(134, 31);
            this.Keresztnév.TabIndex = 27;
            this.Keresztnév.Text = "Keresztnév";
            this.Keresztnév.Visible = false;
            // 
            // K_sz
            // 
            this.K_sz.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.K_sz.Location = new System.Drawing.Point(374, 354);
            this.K_sz.Name = "K_sz";
            this.K_sz.Size = new System.Drawing.Size(172, 20);
            this.K_sz.TabIndex = 26;
            this.K_sz.Visible = false;
            // 
            // adatkezelés
            // 
            this.adatkezelés.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.adatkezelés.AutoSize = true;
            this.adatkezelés.Location = new System.Drawing.Point(374, 400);
            this.adatkezelés.Name = "adatkezelés";
            this.adatkezelés.Size = new System.Drawing.Size(349, 17);
            this.adatkezelés.TabIndex = 28;
            this.adatkezelés.Text = "Elolvastam és elfogadom az ÁSZF-et és az Adatvédelmi tájékoztató-t";
            this.adatkezelés.UseVisualStyleBackColor = true;
            this.adatkezelés.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(785, 492);
            this.Controls.Add(this.adatkezelés);
            this.Controls.Add(this.Keresztnév);
            this.Controls.Add(this.K_sz);
            this.Controls.Add(this.Vezetéknév);
            this.Controls.Add(this.V_sz);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.e_sz);
            this.Controls.Add(this.Mutasd_r_m);
            this.Controls.Add(this.Jelszó_megerősítés);
            this.Controls.Add(this.j_m_sz);
            this.Controls.Add(this.Mégse_r);
            this.Controls.Add(this.Küldés);
            this.Controls.Add(this.Mutasd_r);
            this.Controls.Add(this.Jelszó_r);
            this.Controls.Add(this.j_r_sz);
            this.Controls.Add(this.Felhasználónév_r);
            this.Controls.Add(this.f_r_sz);
            this.Controls.Add(this.Regisztráció_c);
            this.Controls.Add(this.Mutasd_b);
            this.Controls.Add(this.Mégse_b);
            this.Controls.Add(this.Belépés_g);
            this.Controls.Add(this.j_b_sz);
            this.Controls.Add(this.Jelszó_b);
            this.Controls.Add(this.f_b_sz);
            this.Controls.Add(this.Felhasználónév_b);
            this.Controls.Add(this.Belépés_c);
            this.Controls.Add(this.Regisztráció);
            this.Controls.Add(this.Belépés);
            this.Controls.Add(this.Batyu);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Batyu;
        private System.Windows.Forms.Button Belépés;
        private System.Windows.Forms.Button Regisztráció;
        private System.Windows.Forms.Label Belépés_c;
        private System.Windows.Forms.Label Felhasználónév_b;
        private System.Windows.Forms.TextBox f_b_sz;
        private System.Windows.Forms.TextBox j_b_sz;
        private System.Windows.Forms.Label Jelszó_b;
        private System.Windows.Forms.Button Belépés_g;
        private System.Windows.Forms.Button Mégse_b;
        private System.Windows.Forms.CheckBox Mutasd_b;
        private System.Windows.Forms.Label Regisztráció_c;
        private System.Windows.Forms.TextBox f_r_sz;
        private System.Windows.Forms.Label Felhasználónév_r;
        private System.Windows.Forms.Label Jelszó_r;
        private System.Windows.Forms.TextBox j_r_sz;
        private System.Windows.Forms.CheckBox Mutasd_r;
        private System.Windows.Forms.Button Küldés;
        private System.Windows.Forms.Button Mégse_r;
        private System.Windows.Forms.CheckBox Mutasd_r_m;
        private System.Windows.Forms.Label Jelszó_megerősítés;
        private System.Windows.Forms.TextBox j_m_sz;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.TextBox e_sz;
        private System.Windows.Forms.Label Vezetéknév;
        private System.Windows.Forms.TextBox V_sz;
        private System.Windows.Forms.Label Keresztnév;
        private System.Windows.Forms.TextBox K_sz;
        private System.Windows.Forms.CheckBox adatkezelés;
    }
}

